package edu.alexandra.blackjack.domain;

public enum MoveType {
    HIT, STAND
}
