package edu.alexandra.blackjack.domain;

public enum GameStatus {
    STARTED, ONGOING, FINISHED
}
