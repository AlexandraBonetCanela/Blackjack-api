package edu.alexandra.blackjack.domain;

public enum GameResult {
    BUST, WON, LOST, DRAW
}
